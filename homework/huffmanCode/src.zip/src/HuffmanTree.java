import java.io.IOException;

public class HuffmanTree {
  private HuffmanNode root;

  private static class HuffmanNode implements Comparable<HuffmanNode> {
    final public String symbols;
    final public Double frequency;
    final public HuffmanNode left, right;

    //public HuffmanNode(String symbol, double frequency) {}
    //public HuffmanNode(HuffmanNode left, HuffmanNode right) {}
    //public int compareTo(HuffmanNode hn) {}

    public String toString() {
      return "<" + symbols + ", " + frequency + ">";
    }
  }

  // public HuffmanTree(HuffmanNode root) {}
  // public void printLegend() {}
  // public void printTreeSpec() {}

  //public static BinaryHeap freqToHeap(String frequencyStr) {}

  //public static HuffmanTree createFromHeap(BinaryHeap<HuffmanNode> b) {}

  // Usage from the command line:
  // cat sample_legend.txt | java HuffmanTree 
  // on windows: type sample_legend.txt | java HuffmanTree
  public static void main(String [] args) throws IOException {
    String mode = (args.length == 0)? "spec": args[0];

    String frequencyStr = StdinToString.read();

    BinaryHeap<HuffmanNode> heap = freqToHeap(frequencyStr);
    HuffmanTree tree = createFromHeap(heap);

    if (mode.toLowerCase().equals("legend")) {
      tree.printLegend();
    } else {
      tree.printTreeSpec();
    }
  }

  public static String convertSymbolToChar(String symbol) {
    if (symbol.equals("space")) return " ";
    if (symbol.equals("eom")) return "\\e";
    if (symbol.equals("|")) return "\\|";
    if (symbol.equals("\\")) return "\\\\";
    return symbol;
  }
}